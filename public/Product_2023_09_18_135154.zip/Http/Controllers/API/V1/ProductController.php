<?php

namespace App\Http\Controllers\Api\V1;

use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use App\Services\ProductService;
use App\Http\Controllers\Controller;
use App\Http\Resources\Product\Collection as ProductCollection;

use App\Models\Product;


class ProductController extends Controller
{
    use ApiResponser;
    
    private $productService;

    public function __construct()
    {
        $this->productService = new ProductService;
    }

    public function index(Request $request)
    {
        $products = $this->productService->collection($request->all());
        return $this->collection(new ProductCollection($products));
    }
}
