<?php

namespace App\Services;

use App\Models\Post;
use App\Traits\BaseModel;
use App\Traits\PaginationTrait;

class PostService
{
    use BaseModel, PaginationTrait;

    private $postObj;

    public function __construct()
    {
        $this->postObj = new Post;
    }

    public function collection(array $inputs)
    {
        $posts = $this->postObj->getQB();

        return (isset($inputs['limit']) && $inputs['limit'] == '-1') ? $posts->get() : $posts->paginate($inputs['limit']);
    }
}
