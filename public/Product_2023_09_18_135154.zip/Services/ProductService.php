<?php

namespace App\Services;

use App\Models\Product;
use App\Traits\BaseModel;
use App\Traits\PaginationTrait;

class ProductService
{
    use BaseModel, PaginationTrait;

    private $productObj;

    public function __construct()
    {
        $this->productObj = new Product;
    }

    public function collection(array $inputs)
    {
        $products = $this->productObj->getQB();

        return (isset($inputs['limit']) && $inputs['limit'] == '-1') ? $products->get() : $products->paginate($inputs['limit']);
    }
}
