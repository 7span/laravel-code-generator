<?php

return [
    'entityNotFound' => ':entity not found.',
    'entityCreated' => ':entity created successfully.',
    'entityUpdated' => ':entity has been updated successfully.',
    'entityDeleted' => ':entity deleted successfully.',
    'entityExists' => ':entity already exists.',
    'entityExpire' => ':entity has been expired.',
];
