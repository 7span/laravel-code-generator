<?php

namespace App\Http\Data;

use Illuminate\Http\Request;

class Product
{
    public function __invoke(Request $request)
    {
        $request->validate($this->rules());
        return $request->all();
    }

    private function rules(): array
    {
        return [];
    }
}
