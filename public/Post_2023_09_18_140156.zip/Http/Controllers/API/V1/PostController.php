<?php

namespace App\Http\Controllers\Api\V1;

use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use App\Services\PostService;
use App\Http\Controllers\Controller;
use App\Http\Resources\Post\Collection as PostCollection;

use App\Models\Post;


class PostController extends Controller
{
    use ApiResponser;
    
    private $postService;

    public function __construct()
    {
        $this->postService = new PostService;
    }

    public function index(Request $request)
    {
        $posts = $this->postService->collection($request->all());
        return $this->collection(new PostCollection($posts));
    }
}
