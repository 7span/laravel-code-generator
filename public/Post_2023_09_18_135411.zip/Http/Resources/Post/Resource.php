<?php

namespace App\Http\Resources\Post;

use App\Traits\ResourceFilterable;
use Illuminate\Http\Resources\Json\JsonResource;

class Resource extends JsonResource
{
    use ResourceFilterable;
    protected $model = 'Post';

    public function toArray($request)
    {
        $data = $this->fields();
        return $data;
    }
}
